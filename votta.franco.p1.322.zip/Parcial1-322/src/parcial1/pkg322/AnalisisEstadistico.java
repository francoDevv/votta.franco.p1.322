
package parcial1.pkg322;


public class AnalisisEstadistico extends Proyecto implements ResultadoActualizable{
    
    private TipoAnalisis tipoAnalisis;

    public AnalisisEstadistico(String nombre, String equipoResponsable, EstadoProyecto estadoActual, TipoAnalisis tipoAnalisis) {
        super(nombre, equipoResponsable, estadoActual);
        this.tipoAnalisis = tipoAnalisis;
    }

    @Override
    public void actualizarResultado(int resultadoActualizado) {

    }

    @Override
    public void actualizarEstado(EstadoProyecto estadoProyecto) {
    }
    
    
}
