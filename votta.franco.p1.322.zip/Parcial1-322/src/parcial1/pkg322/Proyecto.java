
package parcial1.pkg322;


public abstract class Proyecto implements EstadoActualizable{
    private String nombre;
    private String equipoResponsable;
    private EstadoProyecto estadoActual;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estadoActual = estadoActual;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEquipoResponsable() {
        return equipoResponsable;
    }
    
    public String mostrarInformacionProyecto() {
        return "Proyecto {" + " nombre = " + nombre + " equipoResponsable = " + equipoResponsable + " estadoActual = " + estadoActual + '}';
    }
    
    
    

    
}
