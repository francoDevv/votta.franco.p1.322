
package parcial1.pkg322;


public enum TipoAnalisis {
    
    DESCRIPTIVO,
    INFERENCIAL,
    PREDICTIVO
}
