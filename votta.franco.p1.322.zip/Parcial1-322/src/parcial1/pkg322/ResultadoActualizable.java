
package parcial1.pkg322;


public interface ResultadoActualizable {
    
    public void actualizarResultado(int resultadoActualizado);
}
