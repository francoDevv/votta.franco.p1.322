
package parcial1.pkg322;


public class ProyectoDuplicadoException extends RuntimeException{
    
    public ProyectoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
