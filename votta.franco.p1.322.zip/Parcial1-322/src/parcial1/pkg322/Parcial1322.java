
package parcial1.pkg322;


public class Parcial1322 {

    public static void main(String[] args) {
        
        LaboratorioCienciaDeDatos laboratorio = new LaboratorioCienciaDeDatos("Labo322");
        
        cargaProyectos(laboratorio);
        
        
        
    }
    
    public static void cargaProyectos(LaboratorioCienciaDeDatos laboratorio) {
    
        Proyecto pro1 = new ModeloMachineLearning(50, "Proyecto 1", "Equipo 1", EstadoProyecto.EN_DESARROLLO);
        Proyecto pro2 = new ModeloMachineLearning(50, "Proyecto 2", "Equipo 2", EstadoProyecto.ENTRENANDO_MODELO);
        Proyecto pro3 = new ModeloMachineLearning(50, "Proyecto 3", "Equipo 3", EstadoProyecto.FINALIZADO);
        
        
        Proyecto pro4 = new ModeloMachineLearning(50, "Proyecto 3", "Equipo 3", EstadoProyecto.FINALIZADO);
        Proyecto pro5 = new ModeloMachineLearning(50, "Proyecto 4", "Equipo 3", EstadoProyecto.FINALIZADO);
        
        laboratorio.agregarProyecto(pro1);
        laboratorio.agregarProyecto(pro2);
        laboratorio.agregarProyecto(pro3);

        
        laboratorio.mostrarProyecto();
        

    
    } 
    
}
