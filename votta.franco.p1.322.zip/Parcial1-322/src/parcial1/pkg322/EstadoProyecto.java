
package parcial1.pkg322;


public enum EstadoProyecto {
    EN_DESARROLLO,
    ENTRENANDO_MODELO,
    FINALIZADO
}
