
package parcial1.pkg322;

import java.util.ArrayList;
import java.util.List;


public class LaboratorioCienciaDeDatos {
    private String nombre;
    private List<Proyecto> proyectos;

    public LaboratorioCienciaDeDatos(String nombre) {
        this.nombre = nombre;
        this.proyectos = new ArrayList<>();
    }
    
    public void agregarProyecto(Proyecto proyecto) {
        verificarProyecto(proyecto);
        verificarProyectoDuplicado(proyecto);
        proyectos.add(proyecto);
    }
    
    private void verificarProyecto(Proyecto proyecto) {
        if(proyecto == null) {
            throw new IllegalArgumentException("Es un proyecto nulo");
        }
    }
    
    private void verificarProyectoDuplicado(Proyecto proyecto) {
        for(Proyecto p : proyectos) {
            if(p.getNombre().equals(proyecto.getNombre())) {
                throw new ProyectoDuplicadoException("Otro proyecto ya tiene ese nombre");
            }
            
            if(p.getEquipoResponsable().equals(proyecto.getEquipoResponsable())) {
                throw new ProyectoDuplicadoException("Ya existe un proyecto asignado al equipo");
            }
        }
    }
    
    public String mostrarProyecto() {
        for (Proyecto p : proyectos) {
            p.mostrarInformacionProyecto();
        }
        return "Proyecto ";
    }
    
    
    
}
