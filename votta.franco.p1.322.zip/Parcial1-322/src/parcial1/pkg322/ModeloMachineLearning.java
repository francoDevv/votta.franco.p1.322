
package parcial1.pkg322;


public class ModeloMachineLearning extends Proyecto implements ResultadoActualizable{
    
    public int MIN_PORCENTAJE = 0;
    public int MAX_PORCENTAJE = 100;
    private int porcentajeDePrecisionAlcanzado;

    public ModeloMachineLearning(int porcentajeDePrecisionAlcanzado, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        super(nombre, equipoResponsable, estadoActual);
        this.porcentajeDePrecisionAlcanzado = porcentajeDePrecisionAlcanzado;
    }
    
    @Override
    public void actualizarResultado(int resultadoActualizado) {
        this.porcentajeDePrecisionAlcanzado = resultadoActualizado;
    }

    @Override
    public void actualizarEstado(EstadoProyecto estadoProyecto) {
    }
    
    
}
