
package parcial1.pkg322;


public interface EstadoActualizable {
    
    public void actualizarEstado(EstadoProyecto estadoProyecto);
}
