
package parcial1.pkg322;


public class SistemaVisualizacion extends Proyecto{
    
    private int cantidadGraficos;

    public SistemaVisualizacion(int cantidadGraficos, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        super(nombre, equipoResponsable, estadoActual);
        this.cantidadGraficos = cantidadGraficos;
    }

    @Override
    public void actualizarEstado(EstadoProyecto estadoProyecto) {
    }
    
    
}
